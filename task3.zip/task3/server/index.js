const express = require("express");
const http = require("http");
const socketIo = require("socket.io");
const mongoose = require("mongoose");
const Document = require("./models/document");

// Create an Express app
const app = express();
const server = http.createServer(app);
const io = socketIo(server);

// Connect to MongoDB
mongoose.connect("mongodb://localhost:27017/realTimeEditor", {
    useNewUrlParser: true,
    useUnifiedTopology: true,
});

mongoose.connection.once("open", () => {
    console.log("MongoDB connected");
});

// Middleware
app.use(express.json());

// API to get the document content
app.get("/document", async(req, res) => {
    try {
        const document = await Document.findOne();
        res.json(document);
    } catch (err) {
        res.status(500).send("Error fetching document");
    }
});

// API to save the document content
app.post("/document", async(req, res) => {
    const { content } = req.body;
    try {
        let document = await Document.findOne();
        if (!document) {
            document = new Document({ content });
            await document.save();
        } else {
            document.content = content;
            await document.save();
        }
        res.json(document);
    } catch (err) {
        res.status(500).send("Error saving document");
    }
});

// Real-time communication with Socket.io
io.on("connection", (socket) => {
    console.log("A user connected");

    // Listen for document change events and broadcast to all other users
    socket.on("document-change", async(newContent) => {
        // Save changes to the database
        await Document.findOneAndUpdate({}, { content: newContent });

        // Broadcast the changes to all other connected users
        socket.broadcast.emit("document-change", newContent);
    });

    socket.on("disconnect", () => {
        console.log("User disconnected");
    });
});

// Start the server
server.listen(4000, () => {
    console.log("Server running on http://localhost:4000");
});